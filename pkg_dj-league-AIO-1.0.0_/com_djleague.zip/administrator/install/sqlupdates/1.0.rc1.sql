ALTER TABLE `#__djl_leagues` DROP `teams`, DROP `win`, DROP `lose`, DROP `tie`;
