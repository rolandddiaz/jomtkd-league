DROP TABLE IF EXISTS `#__djl_games`;
DROP TABLE IF EXISTS `#__djl_seasons`;
DROP TABLE IF EXISTS `#__djl_tables`;
DROP TABLE IF EXISTS `#__djl_teams`;
DROP TABLE IF EXISTS `#__djl_tournaments`;